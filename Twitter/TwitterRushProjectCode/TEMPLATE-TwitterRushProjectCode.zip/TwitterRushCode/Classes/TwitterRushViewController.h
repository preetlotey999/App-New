//
//  TwitterRushViewController.h
//  TwitterRush

#import <UIKit/UIKit.h>

@interface TwitterRushViewController : UIViewController <UITextFieldDelegate>
{ 

	IBOutlet UITextField *tweetTextField;
	
}

@property(nonatomic, retain) IBOutlet UITextField *tweetTextField;

-(IBAction)updateTwitter:(id)sender; 

@end

